# Access Codes — 2026/27 Season (KEEP PRIVATE, gitignored)

These are the codes each user enters to create/edit their predictions. They match the
`userData` in `src/db/seed.ts`. Distribute to each person privately.

| User   | Role  | Access code |
|--------|-------|-------------|
| Clive  | user  | `Cv7&kRm2`  |
| John   | user  | `Jn4!tPw9`  |
| Dingle | user  | `Dg2#xQs6`  |
| Chris  | admin | `Ch9$zNb3`  |

If you change any code here, update `src/db/seed.ts` to match and re-run `npm run db:seed`
(note: re-seeding resets teams, users and predictions).
